﻿namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cliente cliente = new Cliente();
            cliente.Menu();


        }
    }
}
